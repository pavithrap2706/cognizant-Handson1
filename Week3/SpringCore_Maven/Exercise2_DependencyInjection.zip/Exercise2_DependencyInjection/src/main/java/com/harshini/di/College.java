package com.harshini.di;

public class College {
    public void collegeInfo() {
        System.out.println("🏫 Pavithra Engineering College  - Department of Spring 💐");
    }
}
