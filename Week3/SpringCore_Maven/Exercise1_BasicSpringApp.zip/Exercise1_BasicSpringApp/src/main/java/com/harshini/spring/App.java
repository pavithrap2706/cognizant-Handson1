package com.harshini.spring;

public class App {

	public static void main(String[] args) {
		System.out.println(" Hello Pavithra! Spring  first app ready! ");

	}

}
